# WinGo Tracker Plus – Android Studio project

ಈ ZIP Android Studio source project. ಈ ಚಾಟ್‌ನ runtime ನಲ್ಲಿ Android SDK/Gradle ಇಲ್ಲದ ಕಾರಣ APK binary ಅನ್ನು ಇಲ್ಲಿ compile ಮಾಡಲು ಸಾಧ್ಯವಾಗಲಿಲ್ಲ.

## GitHub ಮೂಲಕ APK ಪಡೆಯುವುದು (ಕಂಪ್ಯೂಟರ್ ಇಲ್ಲದಿದ್ದರೂ ಸಾಧ್ಯ)
1. ZIP ಅನ್ನು extract ಮಾಡಿ.
2. GitHub ನಲ್ಲಿ ಹೊಸ repository ರಚಿಸಿ.
3. Extract ಮಾಡಿದ folder ಒಳಗಿನ ಎಲ್ಲಾ files ಅನ್ನು repository ಗೆ upload ಮಾಡಿ ( `.github/workflows/build-apk.yml` ಸಹಿತ).
4. GitHub repository → Actions ತೆರೆಯಿರಿ. `Build WinGo Tracker APK` workflow ಆಯ್ಕೆ ಮಾಡಿ → Run workflow.
5. Build ಯಶಸ್ವಿಯಾದ ನಂತರ workflow run ನ ಕೆಳಭಾಗದ Artifacts ನಲ್ಲಿ `WinGoTracker-debug-apk` ZIP download ಮಾಡಿ. ಅದರೊಳಗೆ `app-debug.apk` ಇರುತ್ತದೆ.

## Android Studio ಮೂಲಕ
1. `WinGoTrackerAndroid` folder ಅನ್ನು Android Studio-ದಲ್ಲಿ Open ಮಾಡಿ.
2. Gradle sync ಮುಗಿದ ಮೇಲೆ Build → Build Bundle(s) / APK(s) → Build APK(s).
3. APK: `app/build/outputs/apk/debug/app-debug.apk`.

## App ಮಾಹಿತಿ
- ಇದು ನೀವು ನಮೂದಿಸುವ ಹಿಂದಿನ ಫಲಿತಾಂಶಗಳ ಅಂಕಿಅಂಶ ಮತ್ತು history tracker.
- WinGo ಮುಂದಿನ ಫಲಿತಾಂಶವನ್ನು ಖಚಿತವಾಗಿ ಊಹಿಸುವುದಿಲ್ಲ; hack/server bypass ಇಲ್ಲ.
- ಡೇಟಾ ಸಾಧನದ WebView local storage ನಲ್ಲಿ ಉಳಿಯುತ್ತದೆ.
